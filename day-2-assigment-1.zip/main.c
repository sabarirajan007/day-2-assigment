/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>

int main() {
   int arr[5] = {12, 56, 34, 78, 100};
   int i, max = arr[0];
   
   for(i=1; i<5; i++) {
      if(arr[i] > max) {
         max = arr[i];
      }
   }
   
   printf("Largest element in the array is: %d\n", max);
   
   return 0;
}
